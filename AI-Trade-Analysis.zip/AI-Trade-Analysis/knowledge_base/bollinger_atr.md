# Bollinger Bands and ATR

## Bollinger Bands
Bollinger Bands are a 20-period moving average with bands two standard deviations above and below. Price closing outside a band shows the market is stretched, and often mean-reverts toward the middle band in ranges. In strong trends price can ride along the band, so bands alone are not a reversal signal. Narrow bands (a squeeze) often precede large breakouts.

## Average True Range
Average True Range (ATR) measures volatility as the average of the true range over 14 periods. A high ATR relative to price means big swings and higher risk. ATR is used to place stop-losses: a common choice is 1.5 to 2 times ATR away from entry, which avoids stops being hit by normal noise.

## Volatility and risk levels
ATR below 1 percent of price is low volatility, between 1 and 2.5 percent is medium, and above 2.5 percent is high volatility where position size should be reduced.
