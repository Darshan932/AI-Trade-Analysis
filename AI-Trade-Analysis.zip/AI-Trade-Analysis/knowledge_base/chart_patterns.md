# Chart Patterns

## Candlesticks
Green candles show closes above opens (buying pressure) and red candles show closes below opens (selling pressure). A chart dominated by green candles with higher highs and higher lows indicates an uptrend, while lower highs and lower lows indicate a downtrend.

## Reversal patterns
Double tops and head and shoulders patterns suggest an uptrend is ending. Double bottoms and inverse head and shoulders suggest a downtrend is ending. Patterns are confirmed only when price breaks the neckline.

## Continuation patterns
Flags, pennants and ascending triangles usually resolve in the direction of the prior trend. Enter on the breakout and place the stop-loss on the other side of the pattern.

## Reading screenshots
When analysing a chart image, estimate the slope of price across the visible range, the share of bullish candles, and where the latest price sits within the visible high and low range.
