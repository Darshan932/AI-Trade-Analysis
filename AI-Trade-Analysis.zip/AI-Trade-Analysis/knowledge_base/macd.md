# MACD

## Definition
MACD is the 12-period EMA minus the 26-period EMA. The signal line is a 9-period EMA of the MACD line. The histogram is MACD minus the signal line.

## Crossovers
When MACD crosses above the signal line the histogram turns positive, indicating bullish momentum. A cross below the signal line turns the histogram negative and indicates bearish momentum. A rising histogram means momentum is strengthening, a shrinking histogram warns that the move is fading.

## Limitations
MACD is a lagging indicator based on moving averages. It produces false signals in sideways markets, so confirm with trend direction and support or resistance levels.
