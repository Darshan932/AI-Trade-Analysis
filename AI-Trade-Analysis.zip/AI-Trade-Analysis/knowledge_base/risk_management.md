# Risk Management

## Stop-loss
A stop-loss is a pre-defined exit that limits the loss if the trade idea is wrong. Place it where the idea is invalidated, such as beyond a support level or a multiple of ATR from entry, never based on how much you are willing to lose emotionally.

## Reward to risk ratio
The reward to risk ratio compares the distance to the target with the distance to the stop-loss. A ratio of at least 1.5 to 2 is a common minimum. With a 2:1 ratio a trader can be profitable winning only 40 percent of trades.

## Position sizing
Risk a fixed small percentage of capital per trade, typically 1 percent. Position size equals the amount at risk divided by the distance between entry and stop-loss. This keeps every loss small and survivable regardless of the asset price.

## Drawdown and discipline
Avoid averaging down on losing trades, avoid trading without a plan, and cap total open risk. Losing streaks are normal, and small fixed risk keeps drawdowns manageable.
