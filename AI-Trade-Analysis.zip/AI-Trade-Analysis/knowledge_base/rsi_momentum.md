# RSI Momentum

## What RSI measures
The Relative Strength Index (RSI, 14 periods) ranges from 0 to 100 and measures the speed of recent price changes. Readings above 70 are considered overbought and below 30 oversold.

## Using overbought and oversold
Overbought does not mean sell immediately. In strong uptrends RSI can stay above 70 for a long time. Combine RSI with trend: oversold readings in an uptrend are buying opportunities, overbought readings in a downtrend are selling opportunities.

## RSI divergence
Bullish divergence is when price makes a lower low but RSI makes a higher low, hinting that selling pressure is fading. Bearish divergence is price making a higher high while RSI makes a lower high, hinting at weakening momentum and pullback risk.
