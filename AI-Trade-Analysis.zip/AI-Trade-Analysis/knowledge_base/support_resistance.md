# Support and Resistance

## Support
Support is a price area where buyers have repeatedly stepped in, stopping declines. Swing lows form support levels. A close below support is a bearish breakdown and the broken level often becomes resistance.

## Resistance
Resistance is a price area where sellers have repeatedly capped rallies. Swing highs form resistance levels. A close above resistance on strong volume is a bullish breakout, and the broken level often becomes support.

## Trading the levels
Buy near support with a stop just below it, sell near resistance with a stop just above it, and wait for a confirmed close beyond a level before trading a breakout. False breakouts are common, so confirm with volume and momentum.
