# Trend Following

## Moving averages
A simple moving average (SMA) smooths price over N periods. When price is above the 50-day SMA and the 20-day SMA is above the 50-day SMA, the market is in an uptrend and traders prefer buying pullbacks. When both conditions reverse it is a downtrend and traders prefer selling rallies or staying out.

## Golden cross and death cross
A golden cross happens when a short-term average (20 or 50 day) crosses above a long-term average (200 day) and signals strengthening bullish trend. A death cross is the opposite and signals bearish trend. Both are lagging signals and can fail in sideways, choppy markets.

## Sideways markets
When the moving averages are flat and intertwined, the trend is unclear. Trend-following signals whipsaw in ranges, so reduce size, wait for a breakout, or trade the range between support and resistance.
