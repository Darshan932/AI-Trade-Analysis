"""Deterministic analysis engine.

Numbers (signal, entry, stop-loss, targets, position size) are computed here from
the indicators, never by the LLM, so they cannot be hallucinated.  The LLM only
writes the explanation / risk narrative on top of these facts (see llm.py).
"""
import numpy as np
from . import indicators as ind


def _f(x, nd=2):
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), nd)


def analyze(df=None, image=None, current_price=None, capital=10000.0, risk_pct=1.0):
    if df is None and image is None:
        raise ValueError("Provide price data (CSV), a chart image, or both.")
    if df is None and not current_price:
        raise ValueError("For image-only analysis please enter the current price.")

    score, reasons, snap = 0.0, [], {}
    atr = support = resistance = None

    # ---------------- numeric indicators ----------------
    if df is not None:
        d = ind.compute(df)
        last, prev = d.iloc[-1], d.iloc[-2]
        close = float(last["close"])
        atr = float(last["atr"])
        support, resistance = ind.support_resistance(d)

        if last["close"] > last["sma50"] and last["sma20"] > last["sma50"]:
            score += 2; reasons.append("Price is above the 50-day average and the 20-day average is above the 50-day: uptrend.")
        elif last["close"] < last["sma50"] and last["sma20"] < last["sma50"]:
            score -= 2; reasons.append("Price is below the 50-day average and the 20-day average is below the 50-day: downtrend.")
        else:
            score += 0.5 if last["sma20"] > last["sma50"] else -0.5
            reasons.append("Moving averages are mixed: trend is unclear.")

        hist, hist_prev = float(last["macd_hist"]), float(prev["macd_hist"])
        if hist > 0:
            score += 1 if hist >= hist_prev else 0.5
            reasons.append("MACD histogram is positive" + (" and rising: bullish momentum." if hist >= hist_prev else " but fading."))
        else:
            score -= 1 if hist <= hist_prev else 0.5
            reasons.append("MACD histogram is negative" + (" and falling: bearish momentum." if hist <= hist_prev else " but improving."))

        rsi = float(last["rsi"])
        if rsi < 30:
            score += 1; reasons.append(f"RSI {rsi:.0f} is oversold: bounce potential.")
        elif rsi > 70:
            score -= 1; reasons.append(f"RSI {rsi:.0f} is overbought: pullback risk.")
        elif rsi >= 55:
            score += 0.5; reasons.append(f"RSI {rsi:.0f} shows healthy bullish momentum.")
        elif rsi <= 45:
            score -= 0.5; reasons.append(f"RSI {rsi:.0f} shows weak momentum.")
        else:
            reasons.append(f"RSI {rsi:.0f} is neutral.")

        if close < last["bb_low"]:
            score += 0.5; reasons.append("Price closed below the lower Bollinger Band (stretched to the downside).")
        elif close > last["bb_up"]:
            score -= 0.5; reasons.append("Price closed above the upper Bollinger Band (stretched to the upside).")

        snap = {k: _f(last[k]) for k in ("close", "sma20", "sma50", "rsi", "macd", "macd_signal", "macd_hist", "bb_up", "bb_low", "atr")}
        snap["support"], snap["resistance"] = _f(support), _f(resistance)
    else:
        close = float(current_price)

    # ---------------- chart-image signal ----------------
    if image:
        w = 0.5 if df is not None else 1.5
        if image["trend"] == "uptrend":
            score += w; reasons.append("Chart image: candles/line slope upward (uptrend).")
        elif image["trend"] == "downtrend":
            score -= w; reasons.append("Chart image: candles/line slope downward (downtrend).")
        else:
            reasons.append("Chart image: price is moving sideways.")
        if image["method"] == "candle-colour":
            if image["bullish_ratio"] > 0.6:
                score += w / 2; reasons.append(f"Chart image: {image['bullish_ratio']*100:.0f}% of candle pixels are bullish (green).")
            elif image["bullish_ratio"] < 0.4:
                score -= w / 2; reasons.append(f"Chart image: only {image['bullish_ratio']*100:.0f}% of candle pixels are bullish.")
        if atr is None:  # image-only: approximate volatility from the picture
            atr = close * max(0.004, min(0.05, image["volatility"] * 0.12))

    # ---------------- signal ----------------
    if score >= 1.5:
        signal = "BUY"
    elif score <= -1.5:
        signal = "SELL"
    else:
        signal = "HOLD"
    confidence = int(min(92, 48 + abs(score) * 9)) if signal != "HOLD" else int(max(35, 60 - abs(score) * 10))

    # ---------------- trade plan ----------------
    plan = {"entry": None, "stop_loss": None, "target_1": None, "target_2": None,
            "risk_reward": None, "position_size": None, "risk_amount": None}
    risk_unit = 1.5 * atr
    if signal == "BUY":
        plan["entry"] = close
        plan["stop_loss"] = close - risk_unit
        plan["target_1"] = close + 1.5 * risk_unit
        plan["target_2"] = close + 3.0 * risk_unit
    elif signal == "SELL":
        plan["entry"] = close
        plan["stop_loss"] = close + risk_unit
        plan["target_1"] = close - 1.5 * risk_unit
        plan["target_2"] = close - 3.0 * risk_unit
    if plan["entry"] is not None:
        plan["risk_reward"] = 1.5
        plan["risk_amount"] = capital * risk_pct / 100.0
        plan["position_size"] = plan["risk_amount"] / risk_unit if risk_unit > 0 else None
    plan = {k: _f(v) for k, v in plan.items()}

    vol_pct = atr / close * 100 if close else 0
    risk_level = "Low" if vol_pct < 1 else "Medium" if vol_pct < 2.5 else "High"
    watch = None
    if signal == "HOLD" and support is not None:
        watch = {"breakout_above": _f(resistance), "breakdown_below": _f(support)}

    series = None
    if df is not None:
        t = d.tail(120)
        series = {
            "dates": [x.strftime("%Y-%m-%d") for x in t["date"]],
            "close": [_f(x) for x in t["close"]],
            "sma20": [_f(x) for x in t["sma20"]],
            "sma50": [_f(x) for x in t["sma50"]],
            "bb_up": [_f(x) for x in t["bb_up"]],
            "bb_low": [_f(x) for x in t["bb_low"]],
        }

    return {
        "signal": signal, "confidence": confidence, "score": round(score, 2),
        "price": _f(close), "reasons": reasons, "indicators": snap,
        "trade_plan": plan, "watch_levels": watch,
        "risk": {"level": risk_level, "volatility_pct": _f(vol_pct), "atr": _f(atr),
                 "capital": capital, "risk_pct": risk_pct},
        "image": image, "series": series,
        "source": "csv+image" if (df is not None and image) else "csv" if df is not None else "image",
    }
