"""Image-processing workflow for chart screenshots.

Pipeline: validate -> normalise size -> isolate bullish (green) and bearish (red)
candle pixels -> estimate trend slope, candle bias, volatility and where the latest
price sits inside the visible range.  Falls back to a generic "foreground vs
background" mask for single-colour (e.g. line) charts.

This is a classical computer-vision heuristic, not a trained model, so its output is
used as a supporting signal with lower weight than the numeric indicators.
"""
from PIL import Image, ImageFilter
import numpy as np

MAX_W = 640


def _load(path_or_file) -> Image.Image:
    img = Image.open(path_or_file)
    img.load()
    img = img.convert("RGB")
    if img.width > MAX_W:
        img = img.resize((MAX_W, int(img.height * MAX_W / img.width)), Image.LANCZOS)
    return img


def _thirds_centroid(ys, xs, width):
    """Mean y of the points in the left / middle / right third of the chart (None if empty)."""
    res = []
    for k in range(3):
        lo, hi = width * k / 3, width * (k + 1) / 3
        m = (xs >= lo) & (xs < hi)
        res.append(float(ys[m].mean()) if m.sum() > 20 else None)
    return res


def analyze_chart_image(path_or_file) -> dict:
    img = _load(path_or_file)
    arr = np.asarray(img).astype(int)
    h, w, _ = arr.shape
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]

    green = (g > r + 40) & (g > b + 20)
    red = (r > g + 40) & (r > b + 20)
    n_green, n_red = int(green.sum()), int(red.sum())
    method = "candle-colour"

    if n_green + n_red >= 300:
        mask = green | red
        bullish_ratio = n_green / (n_green + n_red)
    else:  # line chart / monochrome: use pixels that differ from the background
        method = "foreground-mask"
        bg = np.median(arr.reshape(-1, 3), axis=0)
        diff = np.abs(arr - bg).sum(axis=2)
        mask = diff > 120
        bullish_ratio = 0.5

    ys, xs = np.nonzero(mask)
    if len(ys) < 100:
        raise ValueError("Could not find chart data in the image. Upload a clear chart screenshot.")

    left, mid, right = _thirds_centroid(ys, xs, w)
    pts = [p for p in (left, mid, right) if p is not None]
    # smaller y = higher on screen = higher price
    slope = (pts[0] - pts[-1]) / h if len(pts) >= 2 else 0.0
    if slope > 0.06:
        trend = "uptrend"
    elif slope < -0.06:
        trend = "downtrend"
    else:
        trend = "sideways"

    top, bottom = float(np.percentile(ys, 2)), float(np.percentile(ys, 98))
    rng = max(bottom - top, 1.0)
    last_y = right if right is not None else float(ys.mean())
    position = 1.0 - (last_y - top) / rng            # 1 = at the highs, 0 = at the lows
    position = float(min(max(position, 0.0), 1.0))

    # volatility = average vertical extent of the drawn pixels per column, relative to chart height
    col_extent = []
    for x in range(0, w, 4):
        col = ys[xs == x]
        if len(col) > 1:
            col_extent.append(col.max() - col.min())
    volatility = float(np.mean(col_extent) / h) if col_extent else 0.0

    edges = img.convert("L").filter(ImageFilter.FIND_EDGES)
    edge_density = float((np.asarray(edges) > 40).mean())

    return {
        "method": method,
        "width": w,
        "height": h,
        "trend": trend,
        "slope": round(slope, 3),
        "bullish_ratio": round(float(bullish_ratio), 3),
        "position_in_range": round(position, 3),
        "volatility": round(volatility, 3),
        "edge_density": round(edge_density, 3),
        "green_pixels": n_green,
        "red_pixels": n_red,
    }
