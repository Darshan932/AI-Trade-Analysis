"""Technical indicators and OHLC loading (pandas / numpy)."""
import io
import numpy as np
import pandas as pd

ALIASES = {
    "date": ["date", "datetime", "time", "timestamp", "day"],
    "open": ["open", "o"],
    "high": ["high", "h"],
    "low": ["low", "l"],
    "close": ["close", "adj close", "adj_close", "c", "price", "last"],
    "volume": ["volume", "vol", "v"],
}


def load_ohlc(file_or_bytes) -> pd.DataFrame:
    """Read a CSV of OHLC(V) data and normalise the column names."""
    if isinstance(file_or_bytes, (bytes, bytearray)):
        file_or_bytes = io.BytesIO(file_or_bytes)
    raw = pd.read_csv(file_or_bytes)
    raw.columns = [str(c).strip().lower() for c in raw.columns]

    out = pd.DataFrame()
    for target, names in ALIASES.items():
        for n in names:
            if n in raw.columns:
                out[target] = raw[n]
                break
    if "close" not in out:
        raise ValueError("CSV must contain a 'close' column (plus optionally date, open, high, low, volume).")
    for col in ("open", "high", "low"):
        if col not in out:
            out[col] = out["close"]
    if "volume" not in out:
        out["volume"] = 0
    if "date" in out:
        out["date"] = pd.to_datetime(out["date"], errors="coerce")
        out = out.dropna(subset=["date"]).sort_values("date")
    else:
        out["date"] = pd.date_range(end=pd.Timestamp.today().normalize(), periods=len(out), freq="D")
    for col in ("open", "high", "low", "close", "volume"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=["close"]).reset_index(drop=True)
    if len(out) < 50:
        raise ValueError("Need at least 50 rows of price data to compute indicators.")
    return out


def compute(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    c = d["close"]
    d["sma20"] = c.rolling(20).mean()
    d["sma50"] = c.rolling(50).mean()
    d["ema12"] = c.ewm(span=12, adjust=False).mean()
    d["ema26"] = c.ewm(span=26, adjust=False).mean()
    d["macd"] = d["ema12"] - d["ema26"]
    d["macd_signal"] = d["macd"].ewm(span=9, adjust=False).mean()
    d["macd_hist"] = d["macd"] - d["macd_signal"]

    delta = c.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    rs = gain / loss.replace(0, np.nan)
    d["rsi"] = (100 - 100 / (1 + rs)).fillna(50)

    std = c.rolling(20).std()
    d["bb_mid"] = d["sma20"]
    d["bb_up"] = d["sma20"] + 2 * std
    d["bb_low"] = d["sma20"] - 2 * std

    prev = c.shift(1)
    tr = pd.concat([d["high"] - d["low"], (d["high"] - prev).abs(), (d["low"] - prev).abs()], axis=1).max(axis=1)
    d["atr"] = tr.ewm(alpha=1 / 14, adjust=False).mean()
    return d


def support_resistance(df: pd.DataFrame, window: int = 5, lookback: int = 120):
    """Nearest swing-low support below and swing-high resistance above the last close."""
    d = df.tail(lookback).reset_index(drop=True)
    last = float(d["close"].iloc[-1])
    lows, highs = [], []
    for i in range(window, len(d) - window):
        seg = d.iloc[i - window: i + window + 1]
        if d["low"].iloc[i] == seg["low"].min():
            lows.append(float(d["low"].iloc[i]))
        if d["high"].iloc[i] == seg["high"].max():
            highs.append(float(d["high"].iloc[i]))
    below = [x for x in lows if x < last]
    above = [x for x in highs if x > last]
    support = max(below) if below else float(d["low"].min())
    resistance = min(above) if above else float(d["high"].max())
    return support, resistance
