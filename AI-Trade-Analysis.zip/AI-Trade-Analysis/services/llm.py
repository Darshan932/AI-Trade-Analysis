"""LLM layer: prompt engineering + provider abstraction + offline fallback.

Provider order: Anthropic (ANTHROPIC_API_KEY) -> OpenAI (OPENAI_API_KEY) -> built-in
rule-based writer, so the project works with no API key.  Providers are called over
plain HTTPS with `requests`-free urllib to keep dependencies small.
"""
import json
import os
import re
import urllib.request

SYSTEM_PROMPT = (
    "You are a cautious trading analyst assistant. You are given computed indicator facts, a "
    "pre-computed trade plan, and retrieved knowledge-base excerpts. Write the explanation using ONLY "
    "those facts. Never invent prices or change the trade-plan numbers. Mention risks and invalidation "
    "conditions. This is educational analysis, not financial advice. "
    'Reply with JSON only: {"summary": str, "risk_analysis": str, "entry_exit_notes": str}.'
)


def _build_prompt(result, symbol, timeframe, chunks):
    ctx = "\n\n".join(f"[{i+1}] {c['title']}\n{c['text']}" for i, c in enumerate(chunks)) or "(no context retrieved)"
    facts = {
        "symbol": symbol, "timeframe": timeframe, "signal": result["signal"],
        "confidence": result["confidence"], "price": result["price"],
        "indicators": result["indicators"], "reasons": result["reasons"],
        "trade_plan": result["trade_plan"], "watch_levels": result["watch_levels"],
        "risk": result["risk"], "chart_image": result["image"],
    }
    return f"KNOWLEDGE BASE:\n{ctx}\n\nFACTS:\n{json.dumps(facts, indent=2)}\n\nWrite the JSON report now."


def _post(url, headers, body, timeout=40):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def _call_anthropic(prompt, system=SYSTEM_PROMPT):
    data = _post(
        "https://api.anthropic.com/v1/messages",
        {"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01", "content-type": "application/json"},
        {"model": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5-5"), "max_tokens": 900, "system": system,
         "messages": [{"role": "user", "content": prompt}]},
    )
    return data["content"][0]["text"]


def _call_openai(prompt, system=SYSTEM_PROMPT):
    data = _post(
        "https://api.openai.com/v1/chat/completions",
        {"Authorization": "Bearer " + os.environ["OPENAI_API_KEY"], "content-type": "application/json"},
        {"model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"), "temperature": 0.3,
         "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]},
    )
    return data["choices"][0]["message"]["content"]


def _provider():
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic", _call_anthropic
    if os.getenv("OPENAI_API_KEY"):
        return "openai", _call_openai
    return None, None


def _parse_json(text):
    m = re.search(r"\{.*\}", text, re.S)
    return json.loads(m.group(0)) if m else json.loads(text)


# ---------------- offline fallback writer ----------------
def _fallback_report(result, symbol, chunks):
    s, p, r = result["signal"], result["trade_plan"], result["risk"]
    summary = (f"{symbol}: the engine reads a {s} bias with {result['confidence']}% confidence at a price of "
               f"{result['price']}. " + " ".join(result["reasons"][:3]))
    if s == "HOLD":
        w = result["watch_levels"] or {}
        entry = ("No trade is suggested right now. Wait for a close above "
                 f"{w.get('breakout_above')} (bullish breakout) or below {w.get('breakdown_below')} (bearish breakdown)." if w else
                 "No trade is suggested right now; wait for a clearer setup.")
    else:
        entry = (f"Entry near {p['entry']}, stop-loss {p['stop_loss']}, first target {p['target_1']}, second target "
                 f"{p['target_2']} (reward:risk {p['risk_reward']}:1). Risking {r['risk_pct']}% of {r['capital']:.0f} "
                 f"suggests about {p['position_size']} units.")
    risk = (f"Volatility is {r['level'].lower()} (ATR is {r['volatility_pct']}% of price). The stop is 1.5x ATR from entry, so a close "
            "beyond it invalidates the idea. Indicators lag and can whipsaw in sideways markets.")
    if chunks:
        risk += f" Relevant guidance: {chunks[0]['title']}."
    return {"summary": summary, "risk_analysis": risk, "entry_exit_notes": entry}


def generate_report(result, symbol, timeframe, chunks):
    name, fn = _provider()
    if fn:
        try:
            rep = _parse_json(fn(_build_prompt(result, symbol, timeframe, chunks)))
            for k in ("summary", "risk_analysis", "entry_exit_notes"):
                rep[k] = str(rep.get(k, ""))
            rep["provider"] = name
            return rep
        except Exception as e:  # network / parsing problems must never break the app
            rep = _fallback_report(result, symbol, chunks)
            rep["provider"] = "fallback"
            rep["note"] = f"{name} call failed ({type(e).__name__}); used offline writer."
            return rep
    rep = _fallback_report(result, symbol, chunks)
    rep["provider"] = "fallback"
    return rep


def answer_question(question, chunks):
    """RAG chat: answer a trading-concepts question from retrieved chunks."""
    if not chunks:
        return {"answer": "I could not find that in the knowledge base. Try asking about RSI, MACD, "
                          "Bollinger Bands, ATR, stop-loss, support/resistance or position sizing.", "provider": "fallback"}
    name, fn = _provider()
    ctx = "\n\n".join(f"[{i+1}] {c['title']}\n{c['text']}" for i, c in enumerate(chunks))
    if fn:
        try:
            sys_p = "Answer the question using only the context. Be concise (max 6 sentences). If the context lacks the answer, say so."
            return {"answer": fn(f"CONTEXT:\n{ctx}\n\nQUESTION: {question}", sys_p).strip(), "provider": name}
        except Exception:
            pass
    best = chunks[0]
    body = re.sub(r"^#+ .*\n", "", best["text"]).strip()
    return {"answer": f"From the knowledge base ({best['title']}): {body[:700]}", "provider": "fallback"}
