"""Retrieval-Augmented Generation: knowledge ingestion + TF-IDF retrieval.

Ingestion: every markdown file in knowledge_base/ is split into heading-based chunks.
Retrieval: TF-IDF (uni+bi-grams) vectors, cosine similarity, top-k chunks.
The retrieved chunks are injected into the LLM prompt so the written analysis is
grounded in the knowledge base instead of the model's memory.

Swap TfidfVectorizer for an embedding model + vector DB (FAISS / Chroma) to scale up.
"""
import os
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


class KnowledgeBase:
    def __init__(self, folder: str):
        self.folder = folder
        self.chunks = []          # {"source","title","text"}
        self.vectorizer = None
        self.matrix = None
        self.ingest()

    # ---------- ingestion ----------
    def ingest(self):
        self.chunks = []
        if not os.path.isdir(self.folder):
            return
        for fname in sorted(os.listdir(self.folder)):
            if not fname.endswith(".md"):
                continue
            with open(os.path.join(self.folder, fname), encoding="utf-8") as f:
                text = f.read()
            doc_title = fname[:-3].replace("_", " ").title()
            parts = re.split(r"\n(?=#{1,3} )", text)
            for p in parts:
                p = p.strip()
                if len(p) < 40:
                    continue
                first = p.splitlines()[0].lstrip("# ").strip()
                self.chunks.append({"source": fname, "title": f"{doc_title} - {first}", "text": p})
        if self.chunks:
            self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
            self.matrix = self.vectorizer.fit_transform([c["text"] for c in self.chunks])

    # ---------- retrieval ----------
    def retrieve(self, query: str, k: int = 4, min_score: float = 0.05):
        if not self.chunks or not query.strip():
            return []
        q = self.vectorizer.transform([query])
        sims = cosine_similarity(q, self.matrix).ravel()
        order = sims.argsort()[::-1][:k]
        return [
            {**self.chunks[i], "score": round(float(sims[i]), 3)}
            for i in order if sims[i] >= min_score
        ]
