const $ = id => document.getElementById(id);

/* ---------- helpers ---------- */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = v => v == null ? '—' : Number(v).toLocaleString(undefined, { maximumFractionDigits: 2 });
const showErr = m => { const e = $('err'); e.textContent = m || ''; e.style.display = m ? 'block' : 'none'; };

/* ---------- status ---------- */
fetch('/api/health').then(r => r.json()).then(h => {
  const s = $('status'); s.classList.add('ok');
  s.textContent = `DB: ${h.database} · LLM: ${h.llm_provider} · KB: ${h.knowledge_chunks} chunks`;
}).catch(() => { $('status').textContent = 'server offline'; });

/* ---------- file pickers ---------- */
function wirePicker(dropId, nameId, onFile) {
  const drop = $(dropId), input = drop.querySelector('input');
  input.addEventListener('change', () => {
    const f = input.files[0];
    $(nameId).textContent = f ? f.name : $(nameId).dataset.def;
    drop.classList.toggle('on', !!f);
    if (onFile) onFile(f);
  });
  $(nameId).dataset.def = $(nameId).textContent;
}
wirePicker('dropCsv', 'csvName');
wirePicker('dropImg', 'imgName', f => {
  const p = $('imgPrev');
  if (f) { p.src = URL.createObjectURL(f); p.style.display = 'block'; } else p.style.display = 'none';
});

/* ---------- analyze ---------- */
async function run(useSample) {
  showErr('');
  const fd = new FormData($('form'));
  if (useSample) { fd.set('use_sample', '1'); fd.delete('csv'); }
  $('go').disabled = $('sample').disabled = true;
  $('go').textContent = 'Analyzing…';
  try {
    const r = await fetch('/api/analyze', { method: 'POST', body: fd });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error || 'Request failed');
    render(j); loadHistory();
  } catch (e) { showErr(e.message); }
  $('go').disabled = $('sample').disabled = false;
  $('go').textContent = 'Analyze';
}
$('form').addEventListener('submit', e => { e.preventDefault(); run(false); });
$('sample').addEventListener('click', () => run(true));

/* ---------- render result ---------- */
function render(j) {
  const a = j.analysis, rep = j.report, p = a.trade_plan;
  $('empty').hidden = true; $('out').hidden = false;

  $('vsym').textContent = `${j.symbol} · ${j.timeframe} · price ${fmt(a.price)}`;
  $('vsig').textContent = a.signal; $('vsig').className = 'sig ' + a.signal;
  const col = { BUY: 'var(--buy)', SELL: 'var(--sell)', HOLD: 'var(--hold)' }[a.signal];
  $('vconf').style.background = col; $('vconf').style.width = '0';
  requestAnimationFrame(() => $('vconf').style.width = a.confidence + '%');
  $('vconfn').textContent = a.confidence + '%';
  $('vrisk').textContent = `Risk: ${a.risk.level} (ATR ${a.risk.volatility_pct}%)`;
  $('vprov').textContent = rep.provider === 'fallback' ? 'Writer: offline engine' : 'Writer: ' + rep.provider;

  // trade plan
  if (p.entry != null) {
    $('plan').innerHTML = `<h3>Trade plan</h3><div class="cells">
      <div class="cell"><span>Entry</span><b>${fmt(p.entry)}</b></div>
      <div class="cell stop"><span>Stop-loss</span><b>${fmt(p.stop_loss)}</b></div>
      <div class="cell tgt"><span>Target 1</span><b>${fmt(p.target_1)}</b></div>
      <div class="cell tgt"><span>Target 2</span><b>${fmt(p.target_2)}</b></div>
      <div class="cell"><span>Position size</span><b>${fmt(p.position_size)} units</b></div>
      <div class="cell"><span>Risk amount</span><b>${fmt(p.risk_amount)}</b></div></div>`;
  } else {
    const w = a.watch_levels || {};
    $('plan').innerHTML = `<h3>Trade plan</h3><p>No trade right now. Watch these levels:</p><div class="cells">
      <div class="cell tgt"><span>Breakout above</span><b>${fmt(w.breakout_above)}</b></div>
      <div class="cell stop"><span>Breakdown below</span><b>${fmt(w.breakdown_below)}</b></div></div>`;
  }

  $('reasons').innerHTML = a.reasons.map(r => `<li>${esc(r)}</li>`).join('');
  $('summary').textContent = rep.summary;
  $('riskText').textContent = rep.risk_analysis;
  $('entryText').textContent = rep.entry_exit_notes + (rep.note ? '  (' + rep.note + ')' : '');

  // image panel
  const im = a.image;
  $('imgPanel').hidden = !im;
  if (im) $('imgInfo').innerHTML = `<div class="kv">
    <span>Method</span><b>${esc(im.method)}</b><span>Trend</span><b>${esc(im.trend)}</b>
    <span>Slope score</span><b>${im.slope}</b><span>Bullish candles</span><b>${Math.round(im.bullish_ratio * 100)}%</b>
    <span>Price in range</span><b>${Math.round(im.position_in_range * 100)}% of visible high</b>
    <span>Volatility</span><b>${im.volatility}</b></div>`;

  $('sources').innerHTML = j.sources.length
    ? j.sources.map(s => `<div class="src"><span>${esc(s.title)}</span><span>sim ${s.score}</span></div>`).join('')
    : '<em class="muted">No sources matched.</em>';

  drawChart(a);
}

/* Dependency-free canvas line chart (works offline) */
function drawChart(a) {
  $('chartPanel').hidden = !a.series;
  if (!a.series) return;
  const s = a.series, p = a.trade_plan, n = s.dates.length;
  const cv = $('chart'), box = cv.parentElement, dpr = window.devicePixelRatio || 1;
  const W = box.clientWidth, H = box.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr; cv.style.width = W + 'px'; cv.style.height = H + 'px';
  const ctx = cv.getContext('2d'); ctx.scale(dpr, dpr);
  const L = [
    { name: 'Close', d: s.close, c: '#5b8cff', w: 2.2 }, { name: 'SMA 20', d: s.sma20, c: '#22d3ee', w: 1.5 },
    { name: 'SMA 50', d: s.sma50, c: '#f59e0b', w: 1.5 }, { name: 'BB upper', d: s.bb_up, c: 'rgba(138,151,192,.55)', w: 1 },
    { name: 'BB lower', d: s.bb_low, c: 'rgba(138,151,192,.55)', w: 1 }
  ];
  const levels = [['Entry', p.entry, '#e6ebff'], ['Stop', p.stop_loss, '#ef4444'], ['Target 1', p.target_1, '#22c55e'], ['Target 2', p.target_2, '#16a34a']].filter(x => x[1] != null);
  const all = L.flatMap(l => l.d).concat(levels.map(x => x[1])).filter(v => v != null);
  const lo = Math.min(...all), hi = Math.max(...all), pad = (hi - lo) * 0.05;
  const m = { l: 56, r: 14, t: 28, b: 26 }, iw = W - m.l - m.r, ih = H - m.t - m.b;
  const X = i => m.l + i / (n - 1) * iw, Y = v => m.t + (1 - (v - (lo - pad)) / (hi - lo + 2 * pad)) * ih;

  function paint(hover) {
    ctx.clearRect(0, 0, W, H); ctx.font = '11px Segoe UI, sans-serif'; ctx.textBaseline = 'middle';
    ctx.strokeStyle = '#212c4a'; ctx.fillStyle = '#8a97c0'; ctx.lineWidth = 1; ctx.textAlign = 'right';
    for (let k = 0; k <= 5; k++) { const v = lo + (hi - lo) * k / 5, y = Y(v); ctx.beginPath(); ctx.moveTo(m.l, y); ctx.lineTo(W - m.r, y); ctx.stroke(); ctx.fillText(v.toFixed(0), m.l - 8, y); }
    ctx.textAlign = 'center';
    for (let k = 0; k <= 5; k++) { const i = Math.round((n - 1) * k / 5); ctx.fillText(s.dates[i].slice(5), X(i), H - 10); }
    levels.forEach(([nm, v, c]) => { ctx.strokeStyle = c; ctx.setLineDash([6, 4]); ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(m.l, Y(v)); ctx.lineTo(W - m.r, Y(v)); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = c; ctx.textAlign = 'left'; ctx.fillText(nm, m.l + 4, Y(v) - 7); });
    L.forEach(l => { ctx.strokeStyle = l.c; ctx.lineWidth = l.w; ctx.beginPath(); let st = false; l.d.forEach((v, i) => { if (v == null) return; st ? ctx.lineTo(X(i), Y(v)) : ctx.moveTo(X(i), Y(v)); st = true; }); ctx.stroke(); });
    let lx = m.l; ctx.textAlign = 'left';
    L.forEach(l => { ctx.fillStyle = l.c; ctx.fillRect(lx, 8, 12, 3); ctx.fillStyle = '#8a97c0'; ctx.fillText(l.name, lx + 17, 10); lx += ctx.measureText(l.name).width + 38; });
    if (hover != null) {
      ctx.strokeStyle = 'rgba(230,235,255,.35)'; ctx.beginPath(); ctx.moveTo(X(hover), m.t); ctx.lineTo(X(hover), H - m.b); ctx.stroke();
      const t = `${s.dates[hover]}  close ${s.close[hover]}`, tw = ctx.measureText(t).width + 16, tx = Math.min(Math.max(X(hover) - tw / 2, m.l), W - m.r - tw);
      ctx.fillStyle = '#0c1326'; ctx.fillRect(tx, m.t + 4, tw, 22); ctx.strokeStyle = '#212c4a'; ctx.strokeRect(tx, m.t + 4, tw, 22);
      ctx.fillStyle = '#e6ebff'; ctx.textAlign = 'left'; ctx.fillText(t, tx + 8, m.t + 15);
      ctx.fillStyle = '#5b8cff'; ctx.beginPath(); ctx.arc(X(hover), Y(s.close[hover]), 4, 0, 7); ctx.fill();
    }
  }
  paint(null);
  cv.onmousemove = e => { const r = cv.getBoundingClientRect(); paint(Math.min(n - 1, Math.max(0, Math.round((e.clientX - r.left - m.l) / iw * (n - 1))))); };
  cv.onmouseleave = () => paint(null);
}

/* ---------- history ---------- */
async function loadHistory() {
  const rows = await (await fetch('/api/analyses')).json();
  $('history').innerHTML = rows.length ? rows.map(r => `
    <div class="item" data-id="${r.id}">
      <div><b>${esc(r.symbol)}</b><small>${esc(r.created_at.slice(0, 16))} · ${esc(r.source)}</small></div>
      <div><span class="tag ${r.signal}">${r.signal}</span><button class="x" data-del="${r.id}" title="Delete">×</button></div>
    </div>`).join('') : '<em>No analyses yet.</em>';
}
$('history').addEventListener('click', async e => {
  const del = e.target.closest('[data-del]');
  if (del) { await fetch('/api/analyses/' + del.dataset.del, { method: 'DELETE' }); loadHistory(); return; }
  const it = e.target.closest('.item');
  if (it) { const j = await (await fetch('/api/analyses/' + it.dataset.id)).json(); render(j); window.scrollTo({ top: 0, behavior: 'smooth' }); }
});
loadHistory();

/* ---------- RAG chat ---------- */
$('askForm').addEventListener('submit', async e => {
  e.preventDefault();
  const q = $('q').value.trim(); if (!q) return;
  const box = $('answer'); box.hidden = false; box.textContent = 'Searching knowledge base…';
  try {
    const r = await fetch('/api/ask', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: q }) });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error);
    box.innerHTML = esc(j.answer) + `<small>Sources: ${j.sources.map(s => esc(s.title)).join(' · ') || 'none'} · answered by ${esc(j.provider)}</small>`;
  } catch (err) { box.textContent = err.message; }
});
