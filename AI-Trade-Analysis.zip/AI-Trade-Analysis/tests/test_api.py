import io
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import Config  # noqa: E402
from app import create_app  # noqa: E402


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        Config.DATABASE_URL = f"sqlite:///{os.path.join(cls.tmp, 'test.db')}"
        Config.UPLOAD_FOLDER = os.path.join(cls.tmp, "uploads")
        cls.c = create_app().test_client()
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        cls.csv = open(os.path.join(base, "sample_data", "sample_ohlc.csv"), "rb").read()
        cls.img = os.path.join(base, "sample_data", "sample_chart_uptrend.png")

    def test_health(self):
        j = self.c.get("/api/health").json
        self.assertEqual(j["status"], "ok")
        self.assertGreater(j["knowledge_chunks"], 5)

    def test_sample_analysis_and_history(self):
        r = self.c.post("/api/analyze", data={"use_sample": "1"})
        self.assertEqual(r.status_code, 200)
        a = r.json["analysis"]
        self.assertIn(a["signal"], ("BUY", "SELL", "HOLD"))
        self.assertTrue(r.json["sources"])
        if a["signal"] == "BUY":
            p = a["trade_plan"]
            self.assertLess(p["stop_loss"], p["entry"])
            self.assertGreater(p["target_1"], p["entry"])
        rid = r.json["id"]
        self.assertEqual(self.c.get(f"/api/analyses/{rid}").status_code, 200)
        self.assertTrue(any(x["id"] == rid for x in self.c.get("/api/analyses").json))
        self.assertTrue(self.c.delete(f"/api/analyses/{rid}").json["ok"])
        self.assertEqual(self.c.get(f"/api/analyses/{rid}").status_code, 404)

    def test_csv_upload(self):
        r = self.c.post("/api/analyze", data={"csv": (io.BytesIO(self.csv), "x.csv"), "symbol": "abc"},
                        content_type="multipart/form-data")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["symbol"], "ABC")

    def test_image_only_needs_price(self):
        data = {"chart": (open(self.img, "rb"), "c.png")}
        self.assertEqual(self.c.post("/api/analyze", data=data, content_type="multipart/form-data").status_code, 400)
        data = {"chart": (open(self.img, "rb"), "c.png"), "price": "250"}
        r = self.c.post("/api/analyze", data=data, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["analysis"]["image"]["trend"], "uptrend")

    def test_bad_inputs(self):
        self.assertEqual(self.c.post("/api/analyze", data={}).status_code, 400)
        r = self.c.post("/api/analyze", data={"csv": (io.BytesIO(b"a,b\n1,2\n"), "bad.csv")}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)
        r = self.c.post("/api/analyze", data={"chart": (io.BytesIO(b"nope"), "x.exe"), "price": "1"}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)
        r = self.c.post("/api/analyze", data={"chart": (io.BytesIO(b"notanimage"), "x.png"), "price": "1"}, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)

    def test_rag_ask(self):
        r = self.c.post("/api/ask", json={"question": "how to place a stop-loss using ATR"})
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json["sources"])
        self.assertEqual(self.c.post("/api/ask", json={"question": ""}).status_code, 400)


if __name__ == "__main__":
    unittest.main()
